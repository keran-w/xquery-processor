package edu.ucsd.xmlqueryprocessor.parser;

public class XQueryParser {

}
