package edu.ucsd.xmlqueryprocessor.entity;

public class AST {

}
