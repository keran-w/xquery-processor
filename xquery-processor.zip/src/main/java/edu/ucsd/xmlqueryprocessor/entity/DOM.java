package edu.ucsd.xmlqueryprocessor.entity;

public class DOM {
    public DOM() {

    }


}
